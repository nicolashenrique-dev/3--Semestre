class Pessoa {
    nome;
    idade;
    
}

const pessoa1 = new Pessoa();
pessoa1.nome = "Carlos";
pessoa1.idade = 25;

console.log(pessoa1);

const pessoa2 = new Pessoa();
pessoa2.nome = "Nicolas";
pessoa2.idade = 17;

console.log(pessoa2);